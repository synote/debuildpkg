#!/usr/bin/python3


def main():
    print('Hi, Python3!')
    input('Press Enter to continue...')
    return


if __name__ == '__main__':
    main()
