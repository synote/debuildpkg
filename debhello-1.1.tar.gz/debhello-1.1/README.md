#build python package

```
cd debhello-1.1
debmake -b':py3'
```
